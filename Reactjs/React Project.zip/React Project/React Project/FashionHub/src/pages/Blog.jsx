import React from 'react'

const Blog = () => {
  return (
    <div>
        <h1 className='text-center text-4xl text-semibold mt-28'> this is Blog</h1>
    </div>
  )
}

export default Blog