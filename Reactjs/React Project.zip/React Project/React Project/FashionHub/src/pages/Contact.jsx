import React from 'react'

const Contact = () => {
  return (
    <div>
    <h1 className='text-center text-4xl text-semibold mt-28'> this is contact</h1>
</div>
  )
}

export default Contact