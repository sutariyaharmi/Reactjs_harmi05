import React from 'react'

const Shop = () => {
  return (
    <div>
        <h1 className='text-center text-4xl text-semibold mt-28'> this is shop</h1>
    </div>
  )
}

export default Shop